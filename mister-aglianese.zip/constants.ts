
export const NAV_ITEMS = ['Dashboard', 'Partite', 'Giocatori', 'Statistiche', 'Mister'];
