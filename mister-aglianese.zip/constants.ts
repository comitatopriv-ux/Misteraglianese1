
export const NAV_ITEMS = ['Dashboard', 'Partite', 'Giocatori', 'Statistiche', 'Mister'];

export const DEFAULT_MATCH_DURATION_MINUTES = 40;
