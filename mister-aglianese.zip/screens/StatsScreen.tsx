import React, { useMemo, useState } from 'react';
import { Target, Users, Shield, Percent, BarChart3, TrendingUp, TrendingDown, ChevronsUpDown } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Player, Tournament } from '../types';
import Modal from '../components/common/Modal';

const StatCard: React.FC<{ label: string; value: string | number; icon: React.ElementType }> = ({ label, value, icon: Icon }) => (
    <div className="bg-aglianese-gray-800 p-4 rounded-lg text-center">
        <Icon className="mx-auto text-aglianese-green mb-2" size={32} />
        <div className="text-3xl font-bold">{value}</div>
        <div className="text-sm text-aglianese-gray-200">{label}</div>
    </div>
);

type LeaderboardPlayer = Player & { score: number | string };

const LeaderboardModal: React.FC<{ isOpen: boolean; onClose: () => void; title: string; players: LeaderboardPlayer[]; unit: string }> = ({ isOpen, onClose, title, players, unit }) => (
    <Modal isOpen={isOpen} onClose={onClose} title={title}>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {players.map((player, index) => (
                <div key={player.id} className="flex items-center justify-between bg-aglianese-gray-700 p-3 rounded-md">
                    <div className="flex items-center gap-3">
                        <span className="font-bold w-6 text-center">{index + 1}.</span>
                        <span>{player.firstName} {player.lastName}</span>
                    </div>
                    <span className="font-bold text-aglianese-green">{player.score} {unit}</span>
                </div>
            ))}
        </div>
    </Modal>
);

const StatsScreen: React.FC = () => {
    const { matches, players, tournaments } = useAppContext();
    const [filterTournamentId, setFilterTournamentId] = useState<string>('all');
    const [leaderboard, setLeaderboard] = useState<{ title: string; players: LeaderboardPlayer[]; unit: string } | null>(null);

    const filteredMatches = useMemo(() => {
        return filterTournamentId === 'all'
            ? matches
            : matches.filter(m => m.tournamentId === filterTournamentId);
    }, [matches, filterTournamentId]);

    const stats = useMemo(() => {
        const totalMatches = filteredMatches.length;
        if (totalMatches === 0) {
            return { wins: 0, draws: 0, losses: 0, goalsFor: 0, goalsAgainst: 0, cleanSheets: 0, winPercentage: '0%', topScorers: [], topAppearances: [] };
        }

        let wins = 0, draws = 0, losses = 0, goalsFor = 0, goalsAgainst = 0, cleanSheets = 0;
        filteredMatches.forEach(m => {
            goalsFor += m.result.home;
            goalsAgainst += m.result.away;
            if (m.result.home > m.result.away) wins++;
            else if (m.result.home < m.result.away) losses++;
            else draws++;
            if (m.result.away === 0) cleanSheets++;
        });

        const winPercentage = totalMatches > 0 ? ((wins / totalMatches) * 100).toFixed(0) + '%' : '0%';
        
        const scorerData: { [playerId: string]: number } = {};
        filteredMatches.forEach(m => {
            m.scorers.forEach(s => {
                scorerData[s.playerId] = (scorerData[s.playerId] || 0) + s.goals;
            });
        });
        const topScorers = Object.entries(scorerData)
            .map(([playerId, goals]) => ({ player: players.find(p => p.id === playerId), goals }))
            .filter(item => item.player)
            .sort((a, b) => b.goals - a.goals)
            .slice(0, 5) as { player: Player; goals: number }[];

        const appearanceData: { [playerId: string]: number } = {};
        filteredMatches.forEach(m => {
            const tournament = tournaments.find(t => t.id === m.tournamentId);
            const weight = tournament?.presenceWeight || 1;
            m.attendees.forEach(a => {
                if (!appearanceData[a.playerId]) appearanceData[a.playerId] = 0;
                appearanceData[a.playerId] += weight;
            });
        });
        const topAppearances = Object.entries(appearanceData)
            .map(([playerId, weighted]) => ({ player: players.find(p => p.id === playerId), weighted }))
            .filter(item => item.player)
            .sort((a, b) => b.weighted - a.weighted)
            .slice(0, 5) as { player: Player; weighted: number }[];

        return { wins, draws, losses, goalsFor, goalsAgainst, cleanSheets, winPercentage, topScorers, topAppearances };
    }, [filteredMatches, players, tournaments]);

    const openLeaderboard = (type: 'scorers' | 'appearances') => {
        if (type === 'scorers') {
            const scorerData: { [playerId: string]: number } = {};
            filteredMatches.forEach(m => {
                m.scorers.forEach(s => {
                    scorerData[s.playerId] = (scorerData[s.playerId] || 0) + s.goals;
                });
            });
            const allScorers = Object.entries(scorerData)
                .map(([playerId, goals]) => {
                    const player = players.find(p => p.id === playerId);
                    return player ? { ...player, score: goals } : null;
                })
                // FIX: Use a specific type predicate to correctly narrow the type after filtering.
                // The original `p is LeaderboardPlayer` predicate was too broad and caused a type error because
                // `LeaderboardPlayer`'s `score` type (`string | number`) is not assignable to the map's output `score` type (`number`).
                .filter((p): p is Player & { score: number } => p !== null)
                .sort((a, b) => (b.score as number) - (a.score as number));
            setLeaderboard({ title: 'Classifica Marcatori', players: allScorers, unit: 'gol' });
        } else {
            const appearanceData: { [playerId: string]: number } = {};
            filteredMatches.forEach(m => {
                const tournament = tournaments.find(t => t.id === m.tournamentId);
                const weight = tournament?.presenceWeight || 1;
                m.attendees.forEach(a => {
                    if (!appearanceData[a.playerId]) appearanceData[a.playerId] = 0;
                    appearanceData[a.playerId] += weight;
                });
            });
            const allAppearances = Object.entries(appearanceData)
                .map(([playerId, weighted]) => {
                    const player = players.find(p => p.id === playerId);
                    return player ? { ...player, score: weighted.toFixed(2) } : null;
                })
                // FIX: Use a specific type predicate to correctly narrow the type after filtering.
                // The original `p is LeaderboardPlayer` predicate was too broad and caused a type error because
                // `LeaderboardPlayer`'s `score` type (`string | number`) is not assignable to the map's output `score` type (`string`).
                .filter((p): p is Player & { score: string } => p !== null)
                .sort((a, b) => parseFloat(b.score as string) - parseFloat(a.score as string));
            setLeaderboard({ title: 'Classifica Presenze (Ponderata)', players: allAppearances, unit: 'pres.' });
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold">Statistiche</h1>
                <select value={filterTournamentId} onChange={e => setFilterTournamentId(e.target.value)} className="bg-aglianese-gray-700 p-2 rounded-md">
                    <option value="all">Tutti i Tornei</option>
                    {tournaments.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
                <StatCard label="Partite Giocate" value={filteredMatches.length} icon={Shield} />
                <StatCard label="% Vittorie" value={stats.winPercentage} icon={Percent} />
                <StatCard label="V-P-S" value={`${stats.wins}-${stats.draws}-${stats.losses}`} icon={BarChart3} />
                <StatCard label="Gol Fatti/Subiti" value={`${stats.goalsFor}-${stats.goalsAgainst}`} icon={ChevronsUpDown} />
                <StatCard label="Gol Fatti" value={stats.goalsFor} icon={TrendingUp} />
                <StatCard label="Clean Sheets" value={stats.cleanSheets} icon={TrendingDown} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-aglianese-gray-800 p-4 rounded-lg">
                    <h2 className="font-bold mb-3 flex items-center gap-2"><Target /> Top Marcatori</h2>
                    <div className="space-y-2">
                        {stats.topScorers.length > 0 ? stats.topScorers.map(({ player, goals }) => (
                            <div key={player.id} className="flex justify-between items-center">
                                <span>{player.firstName} {player.lastName}</span>
                                <span className="font-bold">{goals}</span>
                            </div>
                        )) : <p className="text-sm text-aglianese-gray-400">Nessun dato</p>}
                    </div>
                     {stats.topScorers.length > 0 && <button onClick={() => openLeaderboard('scorers')} className="text-aglianese-green text-sm mt-3">Mostra classifica completa</button>}
                </div>
                 <div className="bg-aglianese-gray-800 p-4 rounded-lg">
                    <h2 className="font-bold mb-3 flex items-center gap-2"><Users /> Top Presenze (Pond.)</h2>
                     <div className="space-y-2">
                        {stats.topAppearances.length > 0 ? stats.topAppearances.map(({ player, weighted }) => (
                            <div key={player.id} className="flex justify-between items-center">
                                <span>{player.firstName} {player.lastName}</span>
                                <span className="font-bold">{weighted.toFixed(2)}</span>
                            </div>
                        )) : <p className="text-sm text-aglianese-gray-400">Nessun dato</p>}
                    </div>
                     {stats.topAppearances.length > 0 && <button onClick={() => openLeaderboard('appearances')} className="text-aglianese-green text-sm mt-3">Mostra classifica completa</button>}
                </div>
            </div>

            {leaderboard && (
                <LeaderboardModal 
                    isOpen={!!leaderboard}
                    onClose={() => setLeaderboard(null)}
                    title={leaderboard.title}
                    players={leaderboard.players}
                    unit={leaderboard.unit}
                />
            )}
        </div>
    );
};

export default StatsScreen;