import React, { useState } from 'react';
import { Edit, Trash2, Plus, List, Users } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { Match } from '../types';
import ConfirmationModal from '../components/common/ConfirmationModal';
import MatchModal from './matches/MatchModal';
import OpponentsList from './matches/OpponentsList';
import OpponentDetailModal from './matches/OpponentDetailModal';

const MatchItem: React.FC<{ match: Match; onEdit: () => void; onDelete: () => void; onView: () => void; }> = ({ match, onEdit, onDelete, onView }) => {
    const { tournaments } = useAppContext();
    const tournament = tournaments.find(t => t.id === match.tournamentId);
    const date = new Date(match.date).toLocaleDateString('it-IT', { day: '2-digit', month: 'long', year: 'numeric' });
    const resultOutcome = match.result.home > match.result.away ? 'V' : match.result.home < match.result.away ? 'S' : 'P';
    const outcomeBg = resultOutcome === 'V' ? 'bg-green-500' : resultOutcome === 'S' ? 'bg-red-500' : 'bg-yellow-500';

    return (
        <div className="bg-aglianese-gray-800 p-4 rounded-lg flex items-center justify-between gap-2">
            <div onClick={onView} className="flex items-center gap-4 flex-grow cursor-pointer">
                <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${outcomeBg}`}>
                    {resultOutcome}
                </div>
                <div>
                    <p className="font-bold">vs {match.opponent}</p>
                    <p className="text-sm text-aglianese-gray-200">{tournament?.name || 'N/A'}</p>
                    <p className="text-xs text-aglianese-gray-400">{date}</p>
                </div>
            </div>
            <div className="flex items-center gap-2">
                 <p className="text-xl font-bold">{match.result.home} - {match.result.away}</p>
                 <button onClick={onEdit} className="p-2 text-blue-400 hover:text-blue-300 rounded-full hover:bg-aglianese-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500" aria-label="Modifica Partita">
                    <Edit size={20} />
                </button>
                <button onClick={onDelete} className="p-2 text-red-400 hover:text-red-300 rounded-full hover:bg-aglianese-gray-700 focus:outline-none focus:ring-2 focus:ring-red-500" aria-label="Elimina Partita">
                    <Trash2 size={20} />
                </button>
            </div>
        </div>
    );
};

const MatchesScreen: React.FC = () => {
    const { matches, deleteMatch, showMatchReport } = useAppContext();
    const [view, setView] = useState<'list' | 'opponents'>('list');
    const [isModalOpen, setModalOpen] = useState(false);
    const [editingMatch, setEditingMatch] = useState<Match | null>(null);
    const [deletingMatchId, setDeletingMatchId] = useState<string | null>(null);
    const [selectedOpponent, setSelectedOpponent] = useState<string | null>(null);

    const handleOpenModal = (match: Match | null = null) => {
        setEditingMatch(match);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setEditingMatch(null);
        setModalOpen(false);
    };

    const openDeleteConfirm = (matchId: string) => {
        setDeletingMatchId(matchId);
    };

    const confirmDelete = () => {
        if (deletingMatchId) {
            deleteMatch(deletingMatchId);
            setDeletingMatchId(null);
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold">Partite</h1>
                <div className="flex items-center bg-aglianese-gray-800 p-1 rounded-lg">
                    <button 
                        onClick={() => setView('list')}
                        className={`px-3 py-1 text-sm font-semibold rounded-md flex items-center gap-2 transition-colors ${view === 'list' ? 'bg-aglianese-green text-white' : 'text-aglianese-gray-200'}`}
                    >
                        <List size={16} /> Elenco
                    </button>
                    <button 
                        onClick={() => setView('opponents')}
                        className={`px-3 py-1 text-sm font-semibold rounded-md flex items-center gap-2 transition-colors ${view === 'opponents' ? 'bg-aglianese-green text-white' : 'text-aglianese-gray-200'}`}
                    >
                        <Users size={16} /> Avversari
                    </button>
                </div>
            </div>

            {view === 'list' ? (
                <>
                    {matches.length > 0 ? (
                        matches.map(match => (
                            <MatchItem 
                                key={match.id} 
                                match={match}
                                onView={() => showMatchReport(match.id)}
                                onEdit={() => handleOpenModal(match)}
                                onDelete={() => openDeleteConfirm(match.id)}
                            />
                        ))
                    ) : (
                        <p className="text-center text-aglianese-gray-200 p-6 bg-aglianese-gray-800 rounded-lg">
                            Nessuna partita registrata. Aggiungine una!
                        </p>
                    )}
                </>
            ) : (
                <OpponentsList onOpponentClick={(opponentName) => setSelectedOpponent(opponentName)} />
            )}


            <button
                onClick={() => handleOpenModal()}
                className="fixed bottom-24 right-4 bg-aglianese-green text-white p-4 rounded-full shadow-lg hover:bg-green-700 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-green-400"
                aria-label="Aggiungi Partita"
            >
                <Plus size={28} />
            </button>
            
            {isModalOpen && (
                <MatchModal isOpen={isModalOpen} onClose={handleCloseModal} match={editingMatch} />
            )}

            <OpponentDetailModal 
                isOpen={!!selectedOpponent}
                opponentName={selectedOpponent}
                onClose={() => setSelectedOpponent(null)}
            />

            <ConfirmationModal
                isOpen={!!deletingMatchId}
                onClose={() => setDeletingMatchId(null)}
                onConfirm={confirmDelete}
                title="Conferma Eliminazione"
                message="Sei sicuro di voler eliminare questa partita? L'azione è irreversibile."
            />
        </div>
    );
};

export default MatchesScreen;