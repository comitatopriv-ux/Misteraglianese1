import React, { useMemo } from 'react';
import { User, Edit, Trash2, Shield, Percent, BarChart3, Users as PlayersIcon } from 'lucide-react';
import { useAppContext } from '../../context/AppContext';
import { Coach, Player } from '../../types';
import Modal from '../../components/common/Modal';

interface CoachDetailModalProps {
  coach: Coach;
  onClose: () => void;
  onEdit: (c: Coach) => void;
  onDelete: (c: Coach) => void;
}

const CoachDetailModal: React.FC<CoachDetailModalProps> = ({ coach, onClose, onEdit, onDelete }) => {
    const { matches, players, showMatchReport } = useAppContext();

    const stats = useMemo(() => {
        const coachedMatches = matches.filter(m => m.coachIds.includes(coach.id));
        
        let wins = 0, draws = 0, losses = 0;
        coachedMatches.forEach(m => {
            if (m.result.home > m.result.away) wins++;
            else if (m.result.home < m.result.away) losses++;
            else draws++;
        });

        const winPercentage = coachedMatches.length > 0 ? ((wins / coachedMatches.length) * 100).toFixed(0) + '%' : 'N/A';

        const playerPresence: { [playerId: string]: number } = {};
        coachedMatches.forEach(m => {
            m.attendees.forEach(a => {
                playerPresence[a.playerId] = (playerPresence[a.playerId] || 0) + 1;
            });
        });
        
        const topPlayers = Object.entries(playerPresence)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([playerId, count]) => {
                const player = players.find(p => p.id === playerId);
                return { player, count };
            }).filter(item => item.player) as { player: Player, count: number }[];


        return { coachedMatches, wins, draws, losses, winPercentage, topPlayers };

    }, [coach, matches, players]);
    
    if (!coach) return null;

    return (
        <Modal isOpen={!!coach} onClose={onClose} title="Dettaglio Mister">
            <div className="space-y-6">
                <div className="bg-aglianese-gray-700 p-4 rounded-lg flex items-center justify-between">
                   <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-aglianese-gray-600 rounded-full flex items-center justify-center">
                            <User size={32} className="text-aglianese-gray-400" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold">{coach.name}</h2>
                        </div>
                   </div>
                    <div className="flex gap-2">
                        <button onClick={() => onEdit(coach)} className="p-3 rounded-full hover:bg-aglianese-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"><Edit size={20} className="text-blue-400" /></button>
                        <button onClick={() => onDelete(coach)} className="p-3 rounded-full hover:bg-aglianese-gray-600 focus:outline-none focus:ring-2 focus:ring-red-500"><Trash2 size={20} className="text-red-400" /></button>
                    </div>
                </div>

                <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="bg-aglianese-gray-700 p-4 rounded-lg"><Shield className="mx-auto mb-2 text-aglianese-green" /> <span className="font-bold text-xl">{stats.coachedMatches.length}</span><p className="text-sm">Partite</p></div>
                    <div className="bg-aglianese-gray-700 p-4 rounded-lg"><Percent className="mx-auto mb-2 text-aglianese-green" /> <span className="font-bold text-xl">{stats.winPercentage}</span><p className="text-sm">% Vittorie</p></div>
                    <div className="bg-aglianese-gray-700 p-4 rounded-lg"><BarChart3 className="mx-auto mb-2 text-aglianese-green" /> <span className="font-bold text-xl">{`${stats.wins}-${stats.draws}-${stats.losses}`}</span><p className="text-sm">V-P-S</p></div>
                </div>
                
                <div className="bg-aglianese-gray-700 p-4 rounded-lg">
                    <h3 className="font-bold text-lg mb-3 flex items-center gap-2"><PlayersIcon/> Giocatori più presenti</h3>
                     <div className="space-y-2">
                        {stats.topPlayers.length > 0 ? stats.topPlayers.map(({ player, count }) => (
                            <div key={player.id} className="flex justify-between items-center text-sm">
                                <span>{player.firstName} {player.lastName}</span>
                                <span className="font-bold">{count} pres.</span>
                            </div>
                        )) : <p className="text-sm text-aglianese-gray-400">Nessun dato</p>}
                    </div>
                </div>

                <div>
                    <h3 className="font-bold text-lg mb-2">Partite Allenate</h3>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                        {stats.coachedMatches.length > 0 ? stats.coachedMatches.map(m => (
                             <div 
                                key={m.id}
                                onClick={() => { onClose(); showMatchReport(m.id); }}
                                className="bg-aglianese-gray-700 p-3 rounded-md flex justify-between items-center text-sm cursor-pointer hover:bg-aglianese-gray-600 transition-colors"
                            >
                                <div>
                                  <span className="font-semibold">vs {m.opponent}</span>
                                  <span className="text-xs text-aglianese-gray-400 block">{new Date(m.date).toLocaleDateString('it-IT')}</span>
                                </div>
                                <span className="font-bold text-lg">{m.result.home} - {m.result.away}</span>
                            </div>
                        )) : <p className="text-aglianese-gray-400 text-center py-4">Nessuna partita allenata.</p>}
                    </div>
                </div>
            </div>
        </Modal>
    );
};

export default CoachDetailModal;