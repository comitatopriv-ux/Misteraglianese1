import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Plus, Trash2, ShieldCheck, UserPlus } from 'lucide-react';
import Modal from '../../components/common/Modal';
import { useAppContext } from '../../context/AppContext';
import { Match, Player } from '../../types';

interface MatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  match?: Match | null;
}

const MatchModal: React.FC<MatchModalProps> = ({ isOpen, onClose, match }) => {
    const { matches, players, coaches, tournaments, addMatch, updateMatch, showToast, showMatchReport } = useAppContext();
    
    const opponents = useMemo(() => [...new Set(matches.map(m => m.opponent).filter(Boolean))], [matches]);

    const [opponent, setOpponent] = useState('');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [tournamentId, setTournamentId] = useState('');
    const [result, setResult] = useState<{ home: string | number; away: string | number }>({ home: '', away: '' });
    const [selectedCoachIds, setSelectedCoachIds] = useState<string[]>([]);
    
    const [attendees, setAttendees] = useState<{ playerId: string; role: 'starter' | 'sub' }[]>([]);
    const [currentAttendeeId, setCurrentAttendeeId] = useState('');
    const [currentAttendeeRole, setCurrentAttendeeRole] = useState<'starter' | 'sub'>('starter');
    
    const [scorers, setScorers] = useState<{ playerId: string; goals: string | number }[]>([]);
    const [currentScorerId, setCurrentScorerId] = useState('');
    const [currentScorerGoals, setCurrentScorerGoals] = useState<string | number>(1);

    const [isTournamentModalOpen, setTournamentModalOpen] = useState(false);

    const availablePlayers = useMemo(() => players.filter(p => !attendees.some(a => a.playerId === p.id)), [players, attendees]);
    const availableScorers = useMemo(() => attendees.map(a => players.find(p => p.id === a.playerId)).filter(Boolean) as Player[], [attendees, players]);

    const getPlayerName = useCallback((playerId: string) => {
        const player = players.find(p => p.id === playerId);
        return player ? `${player.firstName} ${player.lastName}`.trim() : 'Sconosciuto';
    }, [players]);

    useEffect(() => {
        if (match) {
            setOpponent(match.opponent);
            setDate(new Date(match.date).toISOString().split('T')[0]);
            setTournamentId(match.tournamentId);
            setResult(match.result);
            setSelectedCoachIds(match.coachIds);
            setAttendees(match.attendees);
            setScorers(match.scorers);
        } else {
            // Reset form
            setOpponent('');
            setDate(new Date().toISOString().split('T')[0]);
            setTournamentId(tournaments[0]?.id || '');
            setResult({ home: '', away: '' });
            setSelectedCoachIds([]);
            setAttendees([]);
            setScorers([]);
        }
    }, [match, isOpen, tournaments]);

    const handleAddAttendee = () => {
        if (currentAttendeeId && !attendees.some(a => a.playerId === currentAttendeeId)) {
            setAttendees([...attendees, { playerId: currentAttendeeId, role: currentAttendeeRole }]);
            setCurrentAttendeeId('');
        }
    };
    
    const handleRemoveAttendee = (playerId: string) => {
        setAttendees(attendees.filter(a => a.playerId !== playerId));
        // Also remove from scorers if they were one
        setScorers(scorers.filter(s => s.playerId !== playerId));
    }

    const handleAddScorer = () => {
        if (currentScorerId && Number(currentScorerGoals) > 0) {
            // Check if scorer already exists to update goals, otherwise add new
            const existingScorerIndex = scorers.findIndex(s => s.playerId === currentScorerId);
            if (existingScorerIndex > -1) {
                const updatedScorers = [...scorers];
                const newGoals = Number(updatedScorers[existingScorerIndex].goals) + Number(currentScorerGoals);
                updatedScorers[existingScorerIndex] = {...updatedScorers[existingScorerIndex], goals: newGoals };
                setScorers(updatedScorers);
            } else {
                setScorers([...scorers, { playerId: currentScorerId, goals: Number(currentScorerGoals) }]);
            }
            setCurrentScorerId('');
            setCurrentScorerGoals(1);
        }
    };
    
    const handleSubmit = () => {
        const homeGoals = Number(result.home) || 0;
        const awayGoals = Number(result.away) || 0;

        if (!opponent.trim()) {
            showToast('Il nome dell\'avversario è obbligatorio.', 'error');
            return;
        }
        if (!tournamentId) {
            showToast('Seleziona un torneo.', 'error');
            return;
        }

        const totalScorerGoals = scorers.reduce((sum, s) => sum + Number(s.goals), 0);
        if (totalScorerGoals !== homeGoals) {
            showToast(`La somma dei gol dei marcatori (${totalScorerGoals}) non corrisponde al risultato (${homeGoals}).`, 'error');
            return;
        }
        
        // Validation for scorers being in attendees is now handled by UI design, but we can double-check
        for (const scorer of scorers) {
            if (!attendees.some(a => a.playerId === scorer.playerId)) {
                 showToast(`Il marcatore ${getPlayerName(scorer.playerId)} non è tra i presenti.`, 'error');
                return;
            }
        }

        const matchData: Omit<Match, 'id'> = {
            opponent,
            date: new Date(date).toISOString(),
            tournamentId,
            result: { home: homeGoals, away: awayGoals },
            coachIds: selectedCoachIds,
            attendees: attendees,
            scorers: scorers.map(s => ({...s, goals: Number(s.goals)})),
        };

        const savedMatch = match ? { ...match, ...matchData } : addMatch(matchData);

        if (match) {
            updateMatch(savedMatch);
            showToast('Partita aggiornata con successo!', 'success');
        } else {
            showToast('Partita aggiunta con successo!', 'success');
        }
        onClose();
        // Automatically show the report for the new/updated match
        showMatchReport(savedMatch.id);
    };
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title={match ? 'Modifica Partita' : 'Aggiungi Partita'}>
            <div className="space-y-6">
                {/* Dettagli Partita */}
                <div className="space-y-4">
                     <input type="text" list="opponents-list" placeholder="Avversario" value={opponent} onChange={e => setOpponent(e.target.value)} className="w-full bg-aglianese-gray-700 p-2 rounded" />
                      <datalist id="opponents-list">
                        {opponents.map(o => <option key={o} value={o} />)}
                      </datalist>
                     <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-aglianese-gray-700 p-2 rounded" />
                     <div className="flex items-center gap-2">
                         <select value={tournamentId} onChange={e => setTournamentId(e.target.value)} className="w-full bg-aglianese-gray-700 p-2 rounded">
                            <option value="" disabled>Seleziona Torneo</option>
                            {tournaments.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                         </select>
                         <button onClick={() => setTournamentModalOpen(true)} className="p-2 bg-aglianese-green rounded"><ShieldCheck size={20}/></button>
                     </div>
                     <div className="flex items-center gap-2">
                        <input type="number" placeholder="Casa" value={result.home} onChange={e => setResult({ ...result, home: e.target.value })} className="w-full bg-aglianese-gray-700 p-2 rounded text-center" />
                        <span className="font-bold">-</span>
                        <input type="number" placeholder="Ospiti" value={result.away} onChange={e => setResult({ ...result, away: e.target.value })} className="w-full bg-aglianese-gray-700 p-2 rounded text-center" />
                     </div>
                </div>
                {/* Mister */}
                 <div>
                    <h3 className="font-semibold mb-2">Mister Presenti</h3>
                    <div className="grid grid-cols-2 gap-2">
                    {coaches.map(c => (
                        <label key={c.id} className="flex items-center gap-2 bg-aglianese-gray-700 p-2 rounded">
                            <input type="checkbox" checked={selectedCoachIds.includes(c.id)} onChange={() => {
                                setSelectedCoachIds(prev => prev.includes(c.id) ? prev.filter(id => id !== c.id) : [...prev, c.id]);
                            }} className="form-checkbox h-5 w-5 text-aglianese-green bg-gray-800 border-gray-600 rounded focus:ring-aglianese-green"/>
                            {c.name}
                        </label>
                    ))}
                    </div>
                 </div>

                {/* Giocatori Presenti */}
                 <div>
                    <h3 className="font-semibold mb-2 flex items-center gap-2"><UserPlus size={18}/> Giocatori Presenti</h3>
                    <div className="flex gap-2">
                        <select value={currentAttendeeId} onChange={e => setCurrentAttendeeId(e.target.value)} className="flex-grow bg-aglianese-gray-700 p-2 rounded">
                            <option value="" disabled>Seleziona Giocatore</option>
                            {availablePlayers.map(p => <option key={p.id} value={p.id}>{`${p.firstName} ${p.lastName}`.trim()}</option>)}
                        </select>
                        <select value={currentAttendeeRole} onChange={e => setCurrentAttendeeRole(e.target.value as 'starter' | 'sub')} className="bg-aglianese-gray-700 p-2 rounded">
                            <option value="starter">Titolare</option>
                            <option value="sub">Sostituto</option>
                        </select>
                        <button onClick={handleAddAttendee} className="p-2 bg-aglianese-green rounded" disabled={!currentAttendeeId}><Plus size={20}/></button>
                    </div>
                    <div className="mt-2 space-y-1 max-h-32 overflow-y-auto">
                        {attendees.map((a) => (
                            <div key={a.playerId} className="flex justify-between items-center bg-aglianese-gray-700 p-1.5 rounded text-sm">
                                <span>{getPlayerName(a.playerId)} <span className="text-xs text-gray-400">({a.role})</span></span>
                                <button onClick={() => handleRemoveAttendee(a.playerId)} className="text-red-400 p-1"><Trash2 size={16}/></button>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Marcatori */}
                <div>
                     <h3 className="font-semibold mb-2">Marcatori</h3>
                    <div className={`flex gap-2 ${attendees.length === 0 ? 'opacity-50' : ''}`}>
                        <select value={currentScorerId} onChange={e => setCurrentScorerId(e.target.value)} className="flex-grow bg-aglianese-gray-700 p-2 rounded" disabled={attendees.length === 0}>
                            <option value="" disabled>Seleziona Marcatore</option>
                            {availableScorers.map(p => <option key={p.id} value={p.id}>{`${p.firstName} ${p.lastName}`.trim()}</option>)}
                        </select>
                        <input type="number" min="1" value={currentScorerGoals} onChange={e => setCurrentScorerGoals(e.target.value)} className="w-20 bg-aglianese-gray-700 p-2 rounded text-center" disabled={attendees.length === 0} />
                        <button onClick={handleAddScorer} className="p-2 bg-aglianese-green rounded" disabled={!currentScorerId || attendees.length === 0}><Plus size={20}/></button>
                    </div>
                    {attendees.length === 0 && <p className="text-xs text-yellow-400 mt-1">Aggiungi prima i giocatori presenti per poter inserire i marcatori.</p>}
                    <div className="mt-2 space-y-1 max-h-32 overflow-y-auto">
                        {scorers.map((s) => (
                            <div key={s.playerId} className="flex justify-between items-center bg-aglianese-gray-700 p-1.5 rounded text-sm">
                                <span>{getPlayerName(s.playerId)} <span className="text-xs text-gray-400">({s.goals} gol)</span></span>
                                <button onClick={() => setScorers(scorers.filter((sc) => sc.playerId !== s.playerId))} className="text-red-400 p-1"><Trash2 size={16}/></button>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Actions */}
                <div className="sticky bottom-0 bg-aglianese-gray-800 py-4 flex justify-end gap-4">
                    <button onClick={onClose} className="px-4 py-2 rounded-md bg-aglianese-gray-600 hover:bg-aglianese-gray-500">Annulla</button>
                    <button onClick={handleSubmit} className="px-6 py-2 rounded-md bg-aglianese-green hover:bg-green-700 text-white font-bold">Salva Partita</button>
                </div>
            </div>
            {isTournamentModalOpen && <TournamentManagementModal isOpen={isTournamentModalOpen} onClose={() => setTournamentModalOpen(false)} />}
        </Modal>
    );
};


const TournamentManagementModal: React.FC<{ isOpen: boolean; onClose: () => void; }> = ({isOpen, onClose}) => {
    const { tournaments, addTournament, deleteTournament } = useAppContext();
    const [name, setName] = useState('');
    const [weight, setWeight] = useState(1.0);

    const handleAdd = () => {
        if (name.trim()) {
            addTournament({ name: name.trim(), presenceWeight: weight });
            setName('');
            setWeight(1.0);
        }
    }
    
    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Gestisci Tornei">
             <div className="space-y-4">
                 <p className="text-sm text-aglianese-gray-300 bg-aglianese-gray-700 p-3 rounded-md">
                     Il peso presenza influisce sulle statistiche. Esempio: <br/>
                     Partita intera (es. 45') = <b>1</b> presenza <br/>
                     Partita breve (es. 15') = <b>0.33</b> presenze
                 </p>
                <div className="flex gap-2">
                    <input type="text" placeholder="Nome torneo" value={name} onChange={e => setName(e.target.value)} className="flex-grow bg-aglianese-gray-700 p-2 rounded"/>
                    <input type="number" step="0.01" value={weight} onChange={e => setWeight(parseFloat(e.target.value) || 0)} className="w-24 bg-aglianese-gray-700 p-2 rounded text-center" />
                    <button onClick={handleAdd} className="p-2 bg-aglianese-green rounded"><Plus size={20}/></button>
                </div>
                 <div className="space-y-2">
                     {tournaments.map(t => (
                        <div key={t.id} className="flex justify-between items-center bg-aglianese-gray-700 p-2 rounded">
                            <span>{t.name} (Peso: {t.presenceWeight})</span>
                             <button onClick={() => deleteTournament(t.id)} className="p-1 text-red-400"><Trash2 size={16}/></button>
                        </div>
                     ))}
                 </div>
             </div>
        </Modal>
    )
}

export default MatchModal;